#!/bin/bash

# التأكد من أن ADB مثبت
if ! command -v adb &> /dev/null
then
    echo "❌ ADB غير مثبت! يرجى تثبيته باستخدام: apt install adb"
    exit 1
fi

# قائمة الأوامر
while true; do
    clear
    echo "🔹 أداة التحكم بالأندرويد عبر ADB"
    echo "-----------------------------------"
    echo "1️⃣ الاتصال بالجهاز عبر IP"
    echo "2️⃣ عرض الأجهزة المتصلة"
    echo "3️⃣ إعادة تشغيل الهاتف"
    echo "4️⃣ فتح تطبيق معين"
    echo "5️⃣ التقاط لقطة شاشة"
    echo "6️⃣ سحب ملف من الهاتف"
    echo "7️⃣ الخروج"
    echo "-----------------------------------"
    read -p "🔹 اختر رقم الأمر: " choice

    case $choice in
        1)
            read -p "📡 أدخل IP الجهاز (مثال: 192.168.1.100:5555): " device_ip
            adb connect $device_ip
            ;;
        2)
            adb devices
            read -p "🔹 اضغط Enter للمتابعة..."
            ;;
        3)
            adb reboot
            echo "✅ تم إعادة تشغيل الجهاز!"
            ;;
        4)
            read -p "📱 أدخل اسم الحزمة (مثال: com.whatsapp): " package
            adb shell am start -n $package/.Main
            ;;
        5)
            adb shell screencap -p /sdcard/screenshot.png
            adb pull /sdcard/screenshot.png
            echo "✅ تم حفظ لقطة الشاشة!"
            ;;
        6)
            read -p "📂 أدخل مسار الملف على الهاتف: " file_path
            adb pull $file_path
            echo "✅ تم سحب الملف بنجاح!"
            ;;
        7)
            echo "👋 خروج..."
            exit 0
            ;;
        *)
            echo "❌ اختيار غير صحيح! حاول مرة أخرى."
            ;;
    esac
    sleep 2
done
