import os

def check_adb():
    """التأكد من أن ADB مثبت"""
    if os.system("adb version") != 0:
        print("❌ ADB غير مثبت! يرجى تثبيته باستخدام: apt install adb")
        exit(1)

def connect_device():
    ip = input("📡 أدخل IP الجهاز (مثال: 192.168.1.100:5555): ")
    os.system(f"adb connect {ip}")

def list_devices():
    os.system("adb devices")

def reboot_device():
    os.system("adb reboot")
    print("✅ تم إعادة تشغيل الجهاز!")

def open_app():
    package = input("📱 أدخل اسم الحزمة (مثال: com.whatsapp): ")
    os.system(f"adb shell am start -n {package}/.Main")

def take_screenshot():
    os.system("adb shell screencap -p /sdcard/screenshot.png")
    os.system("adb pull /sdcard/screenshot.png")
    print("✅ تم حفظ لقطة الشاشة!")

def pull_file():
    file_path = input("📂 أدخل مسار الملف على الهاتف: ")
    os.system(f"adb pull {file_path}")
    print("✅ تم سحب الملف بنجاح!")

def main():
    check_adb()
    
    while True:
        print("\n🔹 أداة التحكم بالأندرويد عبر ADB")
        print("1️⃣ الاتصال بالجهاز عبر IP")
        print("2️⃣ عرض الأجهزة المتصلة")
        print("3️⃣ إعادة تشغيل الهاتف")
        print("4️⃣ فتح تطبيق معين")
        print("5️⃣ التقاط لقطة شاشة")
        print("6️⃣ سحب ملف من الهاتف")
        print("7️⃣ الخروج")
        choice = input("🔹 اختر رقم الأمر: ")

        if choice == "1":
            connect_device()
        elif choice == "2":
            list_devices()
        elif choice == "3":
            reboot_device()
        elif choice == "4":
            open_app()
        elif choice == "5":
            take_screenshot()
        elif choice == "6":
            pull_file()
        elif choice == "7":
            print("👋 خروج...")
            break
        else:
            print("❌ اختيار غير صحيح! حاول مرة أخرى.")

if __name__ == "__main__":
    main()
